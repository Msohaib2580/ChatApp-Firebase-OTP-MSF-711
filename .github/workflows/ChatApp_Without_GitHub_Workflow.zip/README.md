# ChatApp — GitHub Ready Android Project

Android starter project with Firebase Phone Authentication (real SMS OTP), persistent Firebase session, and an app-generated Device ID.

## Repository structure

```text
ChatApp/
├── app/
├── .github/
│   └── workflows/
│       └── android.yml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── README.md
├── .gitignore
└── LICENSE
```

## Firebase setup

1. Create a Firebase project.
2. Add an Android app with package name `com.chatapp`.
3. Enable Authentication → Phone.
4. Download `google-services.json`.
5. Do **not** commit the real file to GitHub.
6. Put the complete JSON contents into a GitHub Actions repository secret named:

`GOOGLE_SERVICES_JSON`

GitHub: **Settings → Secrets and variables → Actions → New repository secret**

## Automatic APK build

Every push to `main` runs `.github/workflows/android.yml`.

After a successful run:

**GitHub → Actions → Build ChatApp APK → Artifacts → ChatApp-debug-apk**

Download the APK from that artifact.

## Device ID

The app generates a random UUID and stores it locally. It does not use IMEI or other hardware identifiers.

## Local Android Studio build

Open the project in Android Studio, add your Firebase `google-services.json` under `app/`, sync Gradle, and run the app.

## Note

This is an authentication starter project. Full chat, groups, media, calls, notifications, and admin modules are separate features.

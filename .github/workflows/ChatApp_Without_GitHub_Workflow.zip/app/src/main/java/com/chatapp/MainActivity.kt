package com.chatapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var deviceId: DeviceIdManager
    private var verificationId: String? = null

    private lateinit var root: LinearLayout
    private lateinit var phoneInput: EditText
    private lateinit var otpInput: EditText
    private lateinit var status: TextView
    private lateinit var actionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        deviceId = DeviceIdManager(this)

        if (auth.currentUser != null) {
            showHome()
        } else {
            showLogin()
        }
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
    }

    private fun title(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 28f
            setPadding(0, 0, 0, 32)
        }
    }

    private fun showLogin() {
        root = baseLayout()
        root.addView(title("ChatApp"))

        val hint = TextView(this).apply {
            text = "Enter your phone number with country code"
            textSize = 16f
        }
        root.addView(hint)

        phoneInput = EditText(this).apply {
            hint = "+923001234567"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        root.addView(phoneInput, LinearLayout.LayoutParams(-1, -2))

        status = TextView(this)
        root.addView(status)

        actionButton = Button(this).apply {
            text = "Send OTP"
            setOnClickListener { sendOtp() }
        }
        root.addView(actionButton)

        setContentView(root)
    }

    private fun sendOtp() {
        val phone = phoneInput.text.toString().trim()
        if (!phone.startsWith("+") || phone.length < 8) {
            status.text = "Enter a valid international phone number."
            return
        }

        actionButton.isEnabled = false
        status.text = "Sending OTP…"

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(callbacks)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            signIn(credential)
        }

        override fun onVerificationFailed(e: FirebaseException) {
            actionButton.isEnabled = true
            status.text = "OTP failed: ${e.message ?: "Unknown error"}"
        }

        override fun onCodeSent(
            id: String,
            token: PhoneAuthProvider.ForceResendingToken
        ) {
            verificationId = id
            showOtp()
        }
    }

    private fun showOtp() {
        root.removeAllViews()
        root.addView(title("Verify OTP"))

        otpInput = EditText(this).apply {
            hint = "6-digit OTP"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            maxLines = 1
        }
        root.addView(otpInput)

        status = TextView(this).apply {
            text = "Enter the SMS code sent to your number."
        }
        root.addView(status)

        actionButton = Button(this).apply {
            text = "Verify OTP"
            setOnClickListener { verifyOtp() }
        }
        root.addView(actionButton)

        val back = Button(this).apply {
            text = "Change Number"
            setOnClickListener { showLogin() }
        }
        root.addView(back)
    }

    private fun verifyOtp() {
        val code = otpInput.text.toString().trim()
        val id = verificationId

        if (id.isNullOrBlank() || code.length != 6) {
            status.text = "Enter the 6-digit OTP."
            return
        }

        actionButton.isEnabled = false
        status.text = "Verifying…"

        val credential = PhoneAuthProvider.getCredential(id, code)
        signIn(credential)
    }

    private fun signIn(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    deviceId.get()
                    showHome()
                } else {
                    actionButton.isEnabled = true
                    status.text = "Verification failed: ${task.exception?.message ?: "Unknown error"}"
                }
            }
    }

    private fun showHome() {
        root = baseLayout()
        root.addView(title("Home"))

        val user = auth.currentUser
        val phone = user?.phoneNumber ?: "Unknown"
        val id = deviceId.get()

        root.addView(TextView(this).apply {
            text = "Logged in\n\nPhone: $phone\n\nDevice ID:\n$id"
            textSize = 17f
        })

        root.addView(Button(this).apply {
            text = "Logout"
            setOnClickListener {
                auth.signOut()
                showLogin()
            }
        })

        setContentView(root)
    }
}

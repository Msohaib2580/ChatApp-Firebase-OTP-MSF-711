# Add app-specific R8/ProGuard rules here if needed.
